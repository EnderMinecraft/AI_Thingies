#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

MODE="simulator"
DEVICE_NAME="${SIM_DEVICE:-}"
TEAM_ID="${DEVELOPMENT_TEAM:-}"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --build-only)
            MODE="build-only"
            shift
            ;;
        --open)
            MODE="open"
            shift
            ;;
        --device)
            MODE="device"
            if [[ $# -gt 1 && ! "$2" =~ ^-- ]]; then
                TEAM_ID="$2"
                shift
            fi
            shift
            ;;
        --ipa)
            MODE="ipa-unsigned"
            shift
            ;;
        --ipa-signed)
            MODE="ipa-signed"
            if [[ $# -gt 1 && ! "$2" =~ ^-- ]]; then
                TEAM_ID="$2"
                shift
            fi
            shift
            ;;
        --sim)
            DEVICE_NAME="${2:-}"
            shift 2
            ;;
        -h|--help)
            cat <<'EOF'
Usage: ./setup_and_run_macos.sh [options]
  (default)              Generate project, build, and launch in iOS Simulator
  --sim "<name>"         Specify Simulator device name (e.g. "iPhone 16 Pro")
  --build-only           Generate project and compile for iOS Simulator without launching
  --open                 Generate MagnetPlayground.xcodeproj and open in Xcode
  --device [TEAM_ID]     Build for a connected physical iPhone (optional Apple Team ID)
  --ipa                  Build unsigned build/MagnetPlayground-unsigned.ipa (for Sideloadly/AltStore/SideStore)
  --ipa-signed <TEAM_ID> Archive & export signed build/MagnetPlayground.ipa
EOF
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

if [[ "$(uname -s)" != "Darwin" ]]; then
    echo "error: this script must be run on macOS (detected: $(uname -s))." >&2
    exit 1
fi

MACOS_VER="$(sw_vers -productVersion)"
echo "▸ macOS $MACOS_VER ($(uname -m))"

# Locate Xcode.app (preferring XCODE_APP, then active xcode-select, then /Applications/Xcode*.app).
XCODE_DEV="${DEVELOPER_DIR:-}"
if [[ -z "$XCODE_DEV" ]]; then
    if [[ -n "${XCODE_APP:-}" && -d "${XCODE_APP}/Contents/Developer" ]]; then
        XCODE_DEV="${XCODE_APP}/Contents/Developer"
    else
        CURRENT_DEV="$(xcode-select -p 2>/dev/null || true)"
        if [[ "$CURRENT_DEV" == *".app/Contents/Developer" && -d "$CURRENT_DEV" ]]; then
            XCODE_DEV="$CURRENT_DEV"
        else
            FIRST_XCODE="$(ls -d /Applications/Xcode*.app 2>/dev/null | head -n 1 || true)"
            if [[ -n "$FIRST_XCODE" ]]; then
                XCODE_DEV="${FIRST_XCODE}/Contents/Developer"
            fi
        fi
    fi
fi

if [[ -z "$XCODE_DEV" || ! -x "$XCODE_DEV/usr/bin/xcodebuild" ]]; then
    cat >&2 <<EOF
error: full Xcode.app not found (Command Line Tools alone cannot build iOS/SwiftUI).
For macOS 15.8.2 (Sequoia), install Xcode 26.0–26.3 or Xcode 16.3–16.4 from:
  https://developer.apple.com/download/all/
(Avoid Xcode 26.4+, which requires macOS 26.2+.)
After moving Xcode.app to /Applications, run:
  sudo xcode-select -s /Applications/Xcode.app/Contents/Developer
  sudo xcodebuild -license accept
EOF
    exit 1
fi

export DEVELOPER_DIR="$XCODE_DEV"
echo "▸ Using Xcode: $(xcodebuild -version | tr '\n' ' ')"

if ! xcodebuild -checkFirstLaunchStatus >/dev/null 2>&1; then
    cat >&2 <<'EOF'
error: Xcode first-launch setup is incomplete.
Run:
  sudo xcodebuild -license accept
  sudo xcodebuild -runFirstLaunch
EOF
    exit 1
fi

# Check XcodeGen (install via Homebrew if needed).
if ! command -v xcodegen >/dev/null 2>&1; then
    if command -v brew >/dev/null 2>&1; then
        echo "▸ Installing xcodegen via Homebrew..."
        brew install xcodegen
    else
        cat >&2 <<'EOF'
error: xcodegen and Homebrew were not found.
Install Homebrew first, then xcodegen:
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  brew install xcodegen
EOF
        exit 1
    fi
fi

if [[ ! -f "Resources/Magnet.mfxl" ]]; then
    echo "⚠ Resources/Magnet.mfxl not found yet — building without on-device ML weights."
    echo "  Download Magnet.mfxl from https://libraries.dev/magnetic.html (Model tab) for locator/presence/tap."
fi

echo "▸ Generating MagnetPlayground.xcodeproj..."
xcodegen generate --quiet

if [[ "$MODE" == "open" ]]; then
    echo "▸ Opening MagnetPlayground.xcodeproj in Xcode..."
    open MagnetPlayground.xcodeproj
    exit 0
fi

echo "▸ Resolving Swift Package dependencies (Libraries.dev / MagnetKit)..."
xcodebuild -resolvePackageDependencies \
    -project MagnetPlayground.xcodeproj \
    -scheme MagnetPlayground

if [[ "$MODE" == "ipa-unsigned" || "$MODE" == "ipa-signed" || "$MODE" == "device" ]]; then
    if ! xcrun --sdk iphoneos --show-sdk-path >/dev/null 2>&1; then
        cat >&2 <<'EOF'
error: iOS platform SDK (iphoneos) is not installed in Xcode.
Run:
  xcodebuild -downloadPlatform iOS
EOF
        exit 1
    fi
fi

if [[ "$MODE" == "ipa-unsigned" ]]; then
    echo "▸ Building unsigned iOS app (no Apple ID / signing required)..."
    xcodebuild -project MagnetPlayground.xcodeproj \
        -scheme MagnetPlayground \
        -configuration Release \
        -destination "generic/platform=iOS" \
        -derivedDataPath build \
        CODE_SIGNING_ALLOWED=NO \
        CODE_SIGNING_REQUIRED=NO \
        CODE_SIGN_IDENTITY="" \
        build

    APP_PATH="build/Build/Products/Release-iphoneos/MagnetPlayground.app"
    if [[ ! -d "$APP_PATH" ]]; then
        echo "error: expected app bundle not found at $APP_PATH" >&2
        exit 1
    fi

    rm -rf build/ipa-staging
    mkdir -p build/ipa-staging/Payload
    cp -R "$APP_PATH" build/ipa-staging/Payload/
    rm -f build/MagnetPlayground-unsigned.ipa
    (cd build/ipa-staging && zip -qry "../MagnetPlayground-unsigned.ipa" Payload)
    rm -rf build/ipa-staging
    echo "✓ Unsigned IPA ready: build/MagnetPlayground-unsigned.ipa"
    echo "  Sideload it onto your iPhone with Sideloadly, AltStore, or SideStore."
    exit 0
fi

if [[ "$MODE" == "ipa-signed" ]]; then
    if [[ -z "$TEAM_ID" ]]; then
        echo "error: --ipa-signed requires your Apple Team ID (e.g. ./setup_and_run_macos.sh --ipa-signed ABCDE12345)." >&2
        exit 1
    fi
    echo "▸ Archiving signed iOS app (Team: $TEAM_ID)..."
    xcodebuild -project MagnetPlayground.xcodeproj \
        -scheme MagnetPlayground \
        -configuration Release \
        -destination "generic/platform=iOS" \
        -archivePath build/MagnetPlayground.xcarchive \
        DEVELOPMENT_TEAM="$TEAM_ID" \
        -allowProvisioningUpdates \
        archive

    cat > build/ExportOptions.plist <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>method</key>
    <string>debugging</string>
    <key>signingStyle</key>
    <string>automatic</string>
    <key>teamID</key>
    <string>${TEAM_ID}</string>
</dict>
</plist>
EOF
    rm -rf build/ipa-export
    xcodebuild -exportArchive \
        -archivePath build/MagnetPlayground.xcarchive \
        -exportOptionsPlist build/ExportOptions.plist \
        -exportPath build/ipa-export \
        -allowProvisioningUpdates
    mv build/ipa-export/*.ipa build/MagnetPlayground.ipa
    echo "✓ Signed IPA ready: build/MagnetPlayground.ipa"
    exit 0
fi

if [[ "$MODE" == "device" ]]; then
    echo "▸ Building for connected iOS device..."
    EXTRA_ARGS=()
    if [[ -n "$TEAM_ID" ]]; then
        EXTRA_ARGS+=("DEVELOPMENT_TEAM=$TEAM_ID")
    fi
    xcodebuild -project MagnetPlayground.xcodeproj \
        -scheme MagnetPlayground \
        -destination "generic/platform=iOS" \
        -derivedDataPath build \
        -allowProvisioningUpdates \
        "${EXTRA_ARGS[@]}" \
        build
    echo "✓ Device build succeeded. Open MagnetPlayground.xcodeproj in Xcode to run on your iPhone."
    exit 0
fi

# Verify an iOS Simulator runtime is available.
if ! xcrun simctl list runtimes 2>/dev/null | grep -qi "iOS"; then
    cat >&2 <<'EOF'
error: no iOS Simulator runtime installed in Xcode.
Run:
  xcodebuild -downloadPlatform iOS
EOF
    exit 1
fi

# Pick requested or first available iPhone Simulator UDID.
SIM_UDID=""
if [[ -n "$DEVICE_NAME" ]]; then
    SIM_UDID="$(xcrun simctl list devices available | grep -F "$DEVICE_NAME (" | head -n 1 | sed -E 's/.*\(([A-F0-9-]+)\).*/\1/' || true)"
fi
if [[ -z "$SIM_UDID" ]]; then
    SIM_UDID="$(xcrun simctl list devices available | grep -E "iPhone [0-9]+ Pro \(" | head -n 1 | sed -E 's/.*\(([A-F0-9-]+)\).*/\1/' || true)"
fi
if [[ -z "$SIM_UDID" ]]; then
    SIM_UDID="$(xcrun simctl list devices available | grep -E "iPhone " | head -n 1 | sed -E 's/.*\(([A-F0-9-]+)\).*/\1/' || true)"
fi

if [[ -z "$SIM_UDID" ]]; then
    echo "error: no available iPhone simulator found. Create one in Xcode -> Window -> Devices and Simulators." >&2
    exit 1
fi

echo "▸ Building for iOS Simulator ($SIM_UDID)..."
xcodebuild -project MagnetPlayground.xcodeproj \
    -scheme MagnetPlayground \
    -destination "platform=iOS Simulator,id=$SIM_UDID" \
    -derivedDataPath build \
    build

if [[ "$MODE" == "build-only" ]]; then
    echo "✓ Build succeeded (build/Build/Products/Debug-iphonesimulator/MagnetPlayground.app)."
    exit 0
fi

echo "▸ Booting Simulator ($SIM_UDID)..."
xcrun simctl boot "$SIM_UDID" 2>/dev/null || true
open -a "${DEVELOPER_DIR}/Applications/Simulator.app"

APP_PATH="build/Build/Products/Debug-iphonesimulator/MagnetPlayground.app"
echo "▸ Installing and launching com.example.MagnetPlayground..."
xcrun simctl install "$SIM_UDID" "$APP_PATH"
xcrun simctl launch "$SIM_UDID" "com.example.MagnetPlayground"
echo "✓ MagnetPlayground is running in Simulator."

import Foundation
import MagnetKit
import Observation
import SwiftUI

struct GestureFeedEntry: Identifiable, Equatable {
    let id = UUID()
    let timestamp: Date
    let kind: String
    let detail: String
    let point: CGPoint?
}

struct TapRipple: Identifiable, Equatable {
    let id = UUID()
    let location: CGPoint
    let createdAt: Date
}

@Observable
final class MagnetController {
    // MARK: - MagnetKit Configuration

    var locatorEnabled: Bool = true { didSet { applyConfig() } }
    var locatorMode: MagnetLocatorMode = .network { didSet { applyConfig() } }
    var sensorX: Double = 70 { didSet { applyConfig(); updateSimulatedField() } }
    var sensorY: Double = 86 { didSet { applyConfig(); updateSimulatedField() } }
    var magnetFace: Int = 1 { didSet { applyConfig() } }
    var magnetStrength: Double = 6500 { didSet { applyConfig() } }
    var deskPrior: Bool = true { didSet { applyConfig() } }
    var presenceModel: Bool = true { didSet { applyConfig() } }
    var tapModel: Bool = true { didSet { applyConfig() } }
    var gestureSwipeSpeed: Double = 1500 { didSet { applyConfig() } }

    // MARK: - Runtime & Gesture State

    private(set) var isAttached = false
    private(set) var modelLoaded = MagnetModel.bundled != nil
    private(set) var modelVersion = MagnetModel.bundled?.version
    private(set) var gestureLog: [GestureFeedEntry] = []
    private(set) var activeRipples: [TapRipple] = []
    var lastPulseAt: Date?

    // MARK: - Simulator State

    var forceSimulator: Bool = false {
        didSet { updateSimulatedField() }
    }
    var simPuckLocal: CGPoint? {
        didSet { updateSimulatedField() }
    }
    var simHeightCm: Double = 2.5 {
        didSet { updateSimulatedField() }
    }
    var simNorthUp: Bool = true {
        didSet { updateSimulatedField() }
    }
    var simMoment: Double = 6500 {
        didSet { updateSimulatedField() }
    }
    var rootFrame: CGRect = .zero {
        didSet {
            if simPuckLocal == nil, rootFrame.width > 0 {
                simPuckLocal = CGPoint(x: rootFrame.width * 0.5, y: rootFrame.height * 0.42)
            }
            updateSimulatedField()
        }
    }

    var isSimulated: Bool {
        forceSimulator || !MagnetSource.shared.isSensorAvailable
    }

    var sensorPosition: CGPoint {
        CGPoint(x: sensorX, y: sensorY)
    }

    private var gestureHandlerID: UUID?
    private var simAnimationTask: Task<Void, Never>?

    init() {
        applyConfig()
    }

    func applyConfig() {
        let magnet = MagnetSource.shared
        magnet.config.locatorEnabled = locatorEnabled
        magnet.config.locatorMode = locatorMode
        magnet.config.sensorPosition = CGPoint(x: sensorX, y: sensorY)
        magnet.config.magnetFace = magnetFace
        magnet.config.magnetStrength = magnetStrength
        magnet.config.deskPrior = deskPrior
        magnet.config.presenceModel = presenceModel
        magnet.config.tapModel = tapModel
        magnet.config.gestureSwipeSpeed = gestureSwipeSpeed
    }

    func attach() {
        guard !isAttached else { return }
        applyConfig()
        modelLoaded = MagnetModel.bundled != nil
        modelVersion = MagnetModel.bundled?.version

        gestureHandlerID = MagnetSource.shared.addGestureHandler { [weak self] gesture in
            self?.handleGesture(gesture)
        }
        MagnetSource.shared.attach()
        isAttached = true
        updateSimulatedField()
    }

    func detach() {
        guard isAttached else { return }
        simAnimationTask?.cancel()
        simAnimationTask = nil
        if let id = gestureHandlerID {
            MagnetSource.shared.removeGestureHandler(id)
            gestureHandlerID = nil
        }
        MagnetSource.shared.detach()
        MagnetSource.shared.simulatedField = nil
        MagnetSource.shared.simulatedAmbient = nil
        isAttached = false
    }

    func calibrate() {
        MagnetSource.shared.calibrate()
    }

    // MARK: - Simulator Helpers

    func updateSimulatedField() {
        let src = MagnetSource.shared
        guard isAttached, isSimulated else {
            src.simulatedField = nil
            src.simulatedAmbient = nil
            return
        }

        src.simulatedAmbient = MagnetSimulator.ambient
        guard let local = simPuckLocal, rootFrame.width > 0 else {
            src.simulatedField = MagnetSimulator.ambient
            return
        }

        let globalPuck = CGPoint(x: local.x + rootFrame.minX, y: local.y + rootFrame.minY)
        let depth = -(simHeightCm - 0.4)
        let field = MagnetSimulator.field(
            magnet: globalPuck,
            sensor: sensorPosition,
            northUp: simNorthUp,
            moment: simMoment,
            depth: depth
        )
        src.simulatedField = MagnetSimulator.ambient + field
    }

    /// Simulates a quick downward dip and return toward the screen to exercise `.tap` / `.push` / `.pullAway`.
    func simulateAirTapDip() {
        guard isSimulated else { return }
        simAnimationTask?.cancel()
        let baseHeight = max(2.2, simHeightCm)
        let dipHeight = 0.9

        simAnimationTask = Task { @MainActor [weak self] in
            guard let self else { return }
            let stepsDown = 8
            for i in 1...stepsDown {
                if Task.isCancelled { return }
                let t = Double(i) / Double(stepsDown)
                self.simHeightCm = baseHeight + (dipHeight - baseHeight) * t
                try? await Task.sleep(for: .milliseconds(16))
            }
            for i in 1...stepsDown {
                if Task.isCancelled { return }
                let t = Double(i) / Double(stepsDown)
                self.simHeightCm = dipHeight + (baseHeight - dipHeight) * t
                try? await Task.sleep(for: .milliseconds(16))
            }
            self.simHeightCm = baseHeight
        }
    }

    // MARK: - Gesture Handling

    private func handleGesture(_ gesture: MagnetGesture) {
        let entry: GestureFeedEntry
        switch gesture {
        case .tap(let at):
            let coords = at.map { String(format: "(%.0f, %.0f)", $0.x, $0.y) } ?? "no point"
            entry = GestureFeedEntry(timestamp: .now, kind: "Air Tap", detail: coords, point: at)
            let ripplePoint = at ?? CGPoint(x: rootFrame.midX, y: rootFrame.midY)
            spawnRipple(at: ripplePoint)
            lastPulseAt = .now
        case .pullAway(let speed):
            entry = GestureFeedEntry(
                timestamp: .now,
                kind: "Pull Away",
                detail: String(format: "%.1f cm/s", speed),
                point: nil
            )
        case .push(let speed):
            entry = GestureFeedEntry(
                timestamp: .now,
                kind: "Push",
                detail: String(format: "%.1f cm/s", speed),
                point: nil
            )
            lastPulseAt = .now
        case .swipe(let dir, let speed):
            entry = GestureFeedEntry(
                timestamp: .now,
                kind: "Swipe",
                detail: String(format: "(%.2f, %.2f) @ %.0f pt/s", dir.dx, dir.dy, speed),
                point: nil
            )
        }

        gestureLog.insert(entry, at: 0)
        if gestureLog.count > 8 {
            gestureLog.removeLast(gestureLog.count - 8)
        }
    }

    private func spawnRipple(at globalPoint: CGPoint) {
        let local = CGPoint(x: globalPoint.x - rootFrame.minX, y: globalPoint.y - rootFrame.minY)
        let ripple = TapRipple(location: local, createdAt: .now)
        activeRipples.append(ripple)
        Task { @MainActor [weak self] in
            try? await Task.sleep(for: .milliseconds(750))
            self?.activeRipples.removeAll { $0.id == ripple.id }
        }
    }
}

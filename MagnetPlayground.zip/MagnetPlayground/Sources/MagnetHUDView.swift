import MagnetKit
import SwiftUI

struct MagnetHUDView: View {
    let reading: MagnetReading
    @Bindable var controller: MagnetController
    let onOpenSettings: () -> Void

    var body: some View {
        VStack(spacing: 10) {
            topBar
            Spacer()
            if reading.calibrating {
                statusPill(
                    icon: "scope",
                    text: "Calibrating — keep magnets away",
                    tint: .cyan
                )
            } else if reading.tooClose {
                statusPill(
                    icon: "exclamationmark.triangle.fill",
                    text: "Too close (< 2 cm) — move magnet back to avoid overload",
                    tint: .orange
                )
            }
            if !controller.modelLoaded {
                statusPill(
                    icon: "doc.badge.plus",
                    text: "Magnet.mfxl missing — locator/presence/tap models inactive",
                    tint: .yellow
                )
            }
            if controller.isSimulated {
                simulatorPanel
            }
            telemetryCard
        }
        .padding(.horizontal, 16)
        .padding(.top, 8)
        .padding(.bottom, 12)
    }

    private var topBar: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Circle()
                        .fill(statusColor)
                        .frame(width: 8, height: 8)
                    Text("Magnet Playground")
                        .font(.headline)
                        .foregroundStyle(.white)
                }
                Text(subtitleText)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Button {
                controller.calibrate()
            } label: {
                Label("Calibrate", systemImage: "scope")
                    .font(.caption.weight(.semibold))
            }
            .buttonStyle(.bordered)
            .tint(.cyan)

            Button(action: onOpenSettings) {
                Image(systemName: "slider.horizontal.3")
                    .font(.subheadline.weight(.semibold))
            }
            .buttonStyle(.bordered)
            .tint(.white)
            .accessibilityLabel("Magnet Configuration")
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    private var simulatorPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Label("Simulator Puck", systemImage: "hand.draw")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.cyan)
                Spacer()
                Button("Dip (Air Tap)") {
                    controller.simulateAirTapDip()
                }
                .font(.caption2.weight(.semibold))
                .buttonStyle(.borderedProminent)
                .tint(.cyan)
            }

            HStack(spacing: 10) {
                Text(String(format: "Height %.1f cm", controller.simHeightCm))
                    .font(.caption2.monospacedDigit())
                    .foregroundStyle(.secondary)
                    .frame(width: 82, alignment: .leading)
                Slider(value: $controller.simHeightCm, in: 0.6...7.0, step: 0.1)
                    .tint(.cyan)
            }
        }
        .padding(12)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private var telemetryCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            LazyVGrid(
                columns: [
                    GridItem(.flexible()),
                    GridItem(.flexible()),
                    GridItem(.flexible()),
                ],
                spacing: 8
            ) {
                metricCell("Presence", String(format: "%.0f%%", reading.presence * 100))
                metricCell("Pull", String(format: "%.0f%%", reading.pull * 100))
                metricCell(
                    "Height",
                    reading.height.map { String(format: "%.1f cm", $0) } ?? "—"
                )
                metricCell(
                    "Distance",
                    reading.distance.isFinite ? String(format: "%.1f cm", reading.distance) : "∞"
                )
                metricCell("Approach", String(format: "%+.1f cm/s", reading.approachSpeed))
                metricCell("Spread", String(format: "%.0f pt", reading.screenSpread))
            }

            if !controller.gestureLog.isEmpty {
                Divider().overlay(.white.opacity(0.12))
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(controller.gestureLog.prefix(3)) { item in
                        HStack {
                            Text(item.kind)
                                .font(.caption2.weight(.semibold))
                                .foregroundStyle(.cyan)
                            Text(item.detail)
                                .font(.caption2.monospacedDigit())
                                .foregroundStyle(.white.opacity(0.85))
                            Spacer()
                            Text(item.timestamp, style: .time)
                                .font(.caption2.monospacedDigit())
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .padding(12)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    private func metricCell(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.subheadline.weight(.semibold).monospacedDigit())
                .foregroundStyle(.white)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func statusPill(icon: String, text: String, tint: Color) -> some View {
        Label(text, systemImage: icon)
            .font(.caption.weight(.medium))
            .foregroundStyle(.white)
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(tint.opacity(0.25), in: Capsule())
            .overlay(Capsule().stroke(tint.opacity(0.6), lineWidth: 1))
    }

    private var statusColor: Color {
        if reading.tooClose { return .orange }
        if reading.calibrating { return .yellow }
        if !reading.available { return .red }
        return reading.presence > 0.5 ? .green : .gray
    }

    private var subtitleText: String {
        let mode = controller.locatorMode == .network ? "Network" : "Dipole"
        let source = controller.isSimulated ? "Simulated" : "Live Sensor"
        let model = controller.modelLoaded ? "v\(controller.modelVersion ?? "1.0")" : "No Model"
        return "\(source) • \(mode) • \(model)"
    }
}

struct MagnetSettingsSheet: View {
    @Bindable var controller: MagnetController
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("Locator") {
                    Toggle("Locator Enabled", isOn: $controller.locatorEnabled)
                    Picker("Mode", selection: $controller.locatorMode) {
                        Text("Network (ML)").tag(MagnetLocatorMode.network)
                        Text("Dipole (Physics)").tag(MagnetLocatorMode.dipole)
                    }
                    Picker("Magnet Face", selection: $controller.magnetFace) {
                        Text("North Toward User (+1)").tag(1)
                        Text("South Toward User (-1)").tag(-1)
                    }
                    HStack {
                        Text("Strength (µT·cm³)")
                        Spacer()
                        Text("\(Int(controller.magnetStrength))")
                            .monospacedDigit()
                            .foregroundStyle(.secondary)
                    }
                    Slider(value: $controller.magnetStrength, in: 1000...65000, step: 500)
                }

                Section("Sensor Position (Window Points)") {
                    HStack {
                        Text("X: \(Int(controller.sensorX)) pt")
                            .monospacedDigit()
                        Slider(value: $controller.sensorX, in: 0...430, step: 1)
                    }
                    HStack {
                        Text("Y: \(Int(controller.sensorY)) pt")
                            .monospacedDigit()
                        Slider(value: $controller.sensorY, in: 0...932, step: 1)
                    }
                }

                Section("Models & Gestures") {
                    Toggle("Desk Prior", isOn: $controller.deskPrior)
                    Toggle("Presence Model", isOn: $controller.presenceModel)
                    Toggle("Tap Model", isOn: $controller.tapModel)
                    HStack {
                        Text("Swipe Speed")
                        Spacer()
                        Text("\(Int(controller.gestureSwipeSpeed)) pt/s")
                            .monospacedDigit()
                            .foregroundStyle(.secondary)
                    }
                    Slider(value: $controller.gestureSwipeSpeed, in: 500...3000, step: 100)
                }

                Section("Simulator") {
                    Toggle("Force Simulator Input", isOn: $controller.forceSimulator)
                    Toggle("North Pole Up", isOn: $controller.simNorthUp)
                        .onChange(of: controller.simNorthUp) { _, _ in
                            controller.updateSimulatedField()
                        }
                }
            }
            .navigationTitle("MagnetKit Config")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}

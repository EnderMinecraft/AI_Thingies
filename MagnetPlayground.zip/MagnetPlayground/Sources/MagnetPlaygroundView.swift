import MagnetKit
import SwiftUI

struct MagnetPlaygroundView: View {
    @Bindable var controller: MagnetController
    @State private var showSettings = false
    @State private var puckDragStart: CGPoint?

    var body: some View {
        ZStack {
            Color(red: 0.05, green: 0.06, blue: 0.09)
                .ignoresSafeArea()

            TimelineView(.animation) { ctx in
                let now = ctx.date.timeIntervalSinceReferenceDate
                let reading = MagnetSource.shared.reading(now: now)

                ZStack {
                    reactiveFieldGrid(reading: reading)
                    sensorBeacon(reading: reading)
                    locatorReticle(reading: reading)
                    rippleLayer(now: ctx.date)

                    if controller.isSimulated {
                        simulatorPuck
                    }

                    MagnetHUDView(
                        reading: reading,
                        controller: controller,
                        onOpenSettings: { showSettings = true }
                    )
                }
            }
        }
        .background {
            GeometryReader { geo in
                Color.clear
                    .onChange(of: geo.frame(in: .global), initial: true) { _, frame in
                        controller.rootFrame = frame
                    }
            }
            .ignoresSafeArea()
        }
        .sheet(isPresented: $showSettings) {
            MagnetSettingsSheet(controller: controller)
                .presentationDetents([.medium, .large])
        }
        .onAppear {
            controller.attach()
        }
        .onDisappear {
            controller.detach()
        }
    }

    // MARK: - Reactive Field Grid

    private func reactiveFieldGrid(reading: MagnetReading) -> some View {
        let localTarget = localPosition(from: reading.screenPosition)
        let activePull = reading.pull * reading.presence
        let rows = 7
        let cols = 5

        return GeometryReader { geo in
            let w = geo.size.width
            let h = geo.size.height
            let spacingX = w / CGFloat(cols + 1)
            let spacingY = h / CGFloat(rows + 1)

            ZStack(alignment: .topLeading) {
                ForEach(0..<(rows * cols), id: \.self) { index in
                    let row = index / cols
                    let col = index % cols
                    let anchor = CGPoint(
                        x: spacingX * CGFloat(col + 1),
                        y: spacingY * CGFloat(row + 1)
                    )
                    let offset = nodeDeflection(
                        anchor: anchor,
                        target: localTarget,
                        reading: reading,
                        activePull: activePull
                    )
                    let distScale = nodeScale(anchor: anchor, target: localTarget, activePull: activePull)

                    RoundedRectangle(cornerRadius: 5, style: .continuous)
                        .fill(nodeColor(reading: reading, activePull: activePull))
                        .frame(width: 14, height: 14)
                        .scaleEffect(distScale)
                        .position(x: anchor.x + offset.width, y: anchor.y + offset.height)
                }
            }
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }

    private func nodeDeflection(
        anchor: CGPoint,
        target: CGPoint?,
        reading: MagnetReading,
        activePull: Double
    ) -> CGSize {
        guard activePull > 0.02 else { return .zero }

        if let target {
            let dx = target.x - anchor.x
            let dy = target.y - anchor.y
            let dist = hypot(dx, dy)
            guard dist > 1 else { return .zero }
            let falloff = max(0, 1 - dist / 260)
            let magnitude = 26 * activePull * falloff * reading.polarity
            return CGSize(width: (dx / dist) * magnitude, height: (dy / dist) * magnitude)
        }

        let magnitude = 18 * activePull * reading.polarity
        return CGSize(
            width: reading.toward.dx * magnitude,
            height: reading.toward.dy * magnitude
        )
    }

    private func nodeScale(anchor: CGPoint, target: CGPoint?, activePull: Double) -> CGFloat {
        guard let target, activePull > 0.02 else {
            return 1 + CGFloat(activePull * 0.25)
        }
        let dist = hypot(target.x - anchor.x, target.y - anchor.y)
        let boost = max(0, 1 - dist / 200) * activePull
        return 1 + CGFloat(boost * 0.9)
    }

    private func nodeColor(reading: MagnetReading, activePull: Double) -> Color {
        if reading.tooClose {
            return Color.orange.opacity(0.35 + 0.5 * activePull)
        }
        return reading.polarity >= 0
            ? Color.cyan.opacity(0.18 + 0.6 * activePull)
            : Color.pink.opacity(0.18 + 0.6 * activePull)
    }

    // MARK: - Sensor Beacon & Locator Reticle

    private func sensorBeacon(reading: MagnetReading) -> some View {
        let localSensor = CGPoint(
            x: controller.sensorPosition.x - controller.rootFrame.minX,
            y: controller.sensorPosition.y - controller.rootFrame.minY
        )
        let angle = atan2(reading.toward.dy, reading.toward.dx)
        let hasDirection = hypot(reading.toward.dx, reading.toward.dy) > 0.1 && reading.pull > 0.05

        return ZStack {
            Circle()
                .stroke(Color.white.opacity(0.18), style: StrokeStyle(lineWidth: 1, dash: [3, 3]))
                .frame(width: 28, height: 28)

            if hasDirection {
                Image(systemName: "arrow.up")
                    .font(.caption.bold())
                    .foregroundStyle(.cyan)
                    .rotationEffect(.radians(angle + .pi / 2))
                    .offset(
                        x: reading.toward.dx * 20 * reading.pull,
                        y: reading.toward.dy * 20 * reading.pull
                    )
            }
        }
        .position(localSensor)
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }

    @ViewBuilder
    private func locatorReticle(reading: MagnetReading) -> some View {
        if let local = localPosition(from: reading.screenPosition), reading.presence > 0.25 {
            let spreadDiameter = max(44, CGFloat(reading.screenSpread) * 2)
            let pulseBoost: CGFloat = isPulsing ? 1.18 : 1.0

            ZStack {
                Circle()
                    .stroke(
                        Color.cyan.opacity(0.22 * reading.presence),
                        lineWidth: 1.5
                    )
                    .frame(width: spreadDiameter, height: spreadDiameter)

                Circle()
                    .fill(
                        RadialGradient(
                            colors: [
                                Color.cyan.opacity(0.85 * reading.presence),
                                Color.blue.opacity(0.25 * reading.presence),
                                .clear,
                            ],
                            center: .center,
                            startRadius: 2,
                            endRadius: 34
                        )
                    )
                    .frame(width: 68, height: 68)
                    .scaleEffect(pulseBoost)

                Circle()
                    .stroke(Color.white.opacity(0.9), lineWidth: 2)
                    .frame(width: 20, height: 20)
            }
            .position(local)
            .ignoresSafeArea()
            .allowsHitTesting(false)
        }
    }

    // MARK: - Air Tap Ripples

    private func rippleLayer(now: Date) -> some View {
        ZStack {
            ForEach(controller.activeRipples) { ripple in
                let age = min(1, max(0, now.timeIntervalSince(ripple.createdAt) / 0.75))
                Circle()
                    .stroke(Color.cyan.opacity(1 - age), lineWidth: 2.5)
                    .frame(width: 30 + CGFloat(age) * 160, height: 30 + CGFloat(age) * 160)
                    .position(ripple.location)
            }
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }

    // MARK: - Simulator Draggable Puck

    private var simulatorPuck: some View {
        let p = controller.simPuckLocal ?? CGPoint(
            x: max(120, controller.rootFrame.width * 0.5),
            y: max(200, controller.rootFrame.height * 0.42)
        )

        return Circle()
            .fill(
                LinearGradient(
                    colors: [Color(white: 0.38), Color(white: 0.16)],
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
            .overlay(Circle().stroke(Color.white.opacity(0.35), lineWidth: 1.5))
            .overlay(
                Text(controller.simNorthUp ? "N" : "S")
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .foregroundStyle(controller.simNorthUp ? Color.red : Color.cyan)
            )
            .frame(width: 40, height: 40)
            .shadow(color: .black.opacity(0.5), radius: 8, y: 4)
            .position(p)
            .gesture(
                DragGesture(minimumDistance: 1)
                    .onChanged { value in
                        if puckDragStart == nil { puckDragStart = p }
                        let origin = puckDragStart ?? p
                        controller.simPuckLocal = CGPoint(
                            x: origin.x + value.translation.width,
                            y: origin.y + value.translation.height
                        )
                    }
                    .onEnded { _ in
                        puckDragStart = nil
                    }
            )
            .ignoresSafeArea()
    }

    // MARK: - Helpers

    private var isPulsing: Bool {
        guard let t = controller.lastPulseAt else { return false }
        return Date().timeIntervalSince(t) < 0.22
    }

    private func localPosition(from globalPoint: CGPoint?) -> CGPoint? {
        guard let globalPoint else { return nil }
        return CGPoint(
            x: globalPoint.x - controller.rootFrame.minX,
            y: globalPoint.y - controller.rootFrame.minY
        )
    }
}

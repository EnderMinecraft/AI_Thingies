# MagnetPlayground (iOS 17+ / SwiftUI + MagnetKit)

Interactive SwiftUI playground using [MagnetKit](https://github.com/Jakubantalik/Libraries.dev) (`branch: "main"`).

## Hackintosh / macOS 15.8.2 (Sequoia) Setup

### 1. Required macOS Tools (on your Hackintosh)
- **Xcode**: macOS **15.8.2** supports **Xcode 26.0–26.3** (requires macOS 15.6+) or **Xcode 16.3–16.4** (requires macOS 15.2+).
  - Avoid Xcode 26.4+, which requires macOS 26.2+.
  - If the Mac App Store offers a newer Xcode than 15.8.2 supports, download **Xcode 26.3** or **16.4** `.xip` from https://developer.apple.com/download/all/ (or install via `brew install xcodesorg/made/xcodes`), move it to `/Applications/Xcode.app`, then run:
    ```bash
    sudo xcode-select -s /Applications/Xcode.app/Contents/Developer
    sudo xcodebuild -license accept
    xcodebuild -downloadPlatform iOS
    ```
- **Metal note for Hackintosh**: Xcode iOS Simulator and SwiftUI previews rely on Metal GPU acceleration (supported Intel iGPU / AMD dGPU).

### 2. Add the On-Device Model (`Magnet.mfxl`, ~2 MB)
- Download `Magnet.mfxl` from https://libraries.dev/magnetic.html (**Model** tab, free account).
- Place it at `Resources/Magnet.mfxl` (`.gitignore` excludes `*.mfxl` — never commit it to a public repo).
- Model License: free for development and non-commercial apps; commercial releases require Libraries.dev Pro or Business.

### 3. Build an `.ipa` for Sideloading (Works on VMware macOS 15.8.2 — No Metal Needed)
Copy the `MagnetPlayground` folder to your macOS VM / Hackintosh, open Terminal inside it, and run:
```bash
chmod +x setup_and_run_macos.sh
./setup_and_run_macos.sh --ipa
```
This outputs `build/MagnetPlayground-unsigned.ipa` (requires no Apple Developer login during build). Transfer it back to Windows or sideload directly with **Sideloadly**, **AltStore**, or **SideStore** onto your iPhone.

Other modes:
- `./setup_and_run_macos.sh --ipa-signed YOUR_TEAM_ID` — Exports a signed `build/MagnetPlayground.ipa`.
- `./setup_and_run_macos.sh --open` — Generates `MagnetPlayground.xcodeproj` and opens it in Xcode.
- `./setup_and_run_macos.sh --build-only` — Compiles for iOS Simulator without launching.
- `./setup_and_run_macos.sh --device YOUR_TEAM_ID` — Compiles for a connected physical iPhone.
- `./setup_and_run_macos.sh` — Builds and launches in iOS Simulator (bare-metal Hackintosh / Mac with Metal).

## Using the App
- **iPhone**: Keep magnets away during initial calibration, and keep the magnet **2 cm+** from the magnetometer (`r.tooClose`).
- **Simulator**: Drag the simulated magnet puck, adjust height with the slider, and press **Dip (Air Tap)** to drive `MagnetSimulator.field(magnet:sensor:northUp:)`.

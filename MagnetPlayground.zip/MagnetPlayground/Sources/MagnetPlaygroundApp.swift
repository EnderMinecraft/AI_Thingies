import SwiftUI

@main
struct MagnetPlaygroundApp: App {
    @State private var controller = MagnetController()

    var body: some Scene {
        WindowGroup {
            MagnetPlaygroundView(controller: controller)
                .preferredColorScheme(.dark)
        }
    }
}
